package com.darknexus.tv;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.GridLayout;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8,10,14), PANEL = Color.rgb(23,29,39), WHITE = Color.rgb(238,242,248), MUTED = Color.rgb(137,148,164), ACCENT = Color.rgb(169,199,245);
    private LinearLayout root;
    private GridLayout grid;
    private final Handler handler = new Handler();
    private final List<AppEntry> apps = new ArrayList<>();
    private static class AppEntry { String label, pkg; android.graphics.drawable.Drawable icon; AppEntry(String l,String p,android.graphics.drawable.Drawable i){label=l;pkg=p;icon=i;} }

    @Override public void onCreate(Bundle state) { super.onCreate(state); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); build(); loadApps(); }

    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private TextView text(String value, int size, int color, boolean bold) { TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); return t; }
    private void build() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(54,34,54,26); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView title=text("DARK NEXUS",30,WHITE,true); title.setLetterSpacing(.12f); brand.addView(title);
        TextView sub=text("ANDROID TV  /  NEXUS CORE",10,MUTED,true); sub.setLetterSpacing(.18f); brand.addView(sub); top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout clockBox=new LinearLayout(this); clockBox.setOrientation(LinearLayout.VERTICAL); clockBox.setGravity(Gravity.RIGHT);
        TextView clock=text("--:--",25,WHITE,true); TextView date=text("SISTEMA ACTIVO",10,MUTED,false); clockBox.addView(clock); clockBox.addView(date); top.addView(clockBox); root.addView(top);
        handler.post(new Runnable(){ public void run(){ String now=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()); String day=new SimpleDateFormat("EEEE, d MMMM",new Locale("es","HN")).format(new Date()).toUpperCase(new Locale("es","HN")); clock.setText(now); date.setText(day); handler.postDelayed(this,30000); }});
        View line=new View(this); line.setBackgroundColor(Color.rgb(41,49,61)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,1); lp.topMargin=22; lp.bottomMargin=22; root.addView(line,lp);
        TextView section=text("TUS APLICACIONES",12,MUTED,true); section.setLetterSpacing(.16f); root.addView(section);
        grid=new GridLayout(this); grid.setColumnCount(5); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,0,1); gp.topMargin=16; root.addView(grid,gp);
        TextView footer=text("NEXUS CORE     •     CONTROL REMOTO LISTO",10,Color.rgb(92,105,123),false); footer.setLetterSpacing(.12f); root.addView(footer);
    }
    private void loadApps() {
        apps.clear(); PackageManager pm=getPackageManager(); Intent query=new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<android.content.pm.ResolveInfo> found=pm.queryIntentActivities(query,0);
        for(android.content.pm.ResolveInfo ri:found){ String pkg=ri.activityInfo.packageName; if(pkg.equals(getPackageName())) continue; String label=ri.loadLabel(pm).toString(); apps.add(new AppEntry(label,pkg,ri.loadIcon(pm))); }
        if(apps.isEmpty()) { Intent q=new Intent(Intent.ACTION_MAIN); q.addCategory(Intent.CATEGORY_LAUNCHER); for(android.content.pm.ResolveInfo ri:pm.queryIntentActivities(q,0)){String pkg=ri.activityInfo.packageName;if(!pkg.equals(getPackageName()))apps.add(new AppEntry(ri.loadLabel(pm).toString(),pkg,ri.loadIcon(pm)));} }
        Collections.sort(apps,(a,b)->a.label.compareToIgnoreCase(b.label)); renderApps();
    }
    private void renderApps(){ grid.removeAllViews(); int w=(int)(getResources().getDisplayMetrics().widthPixels/5.0f); for(AppEntry app:apps){ LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setBackground(shape(PANEL,22)); card.setFocusable(true); card.setFocusableInTouchMode(true); card.setPadding(8,12,8,10); GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=w-16; p.height=(int)(getResources().getDisplayMetrics().heightPixels*.20f); p.setMargins(5,5,5,5); card.setLayoutParams(p);
        android.widget.ImageView iv=new android.widget.ImageView(this); iv.setImageDrawable(app.icon); iv.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(58,58); ip.bottomMargin=10; card.addView(iv,ip);
        TextView name=text(app.label,12,WHITE,true); name.setGravity(Gravity.CENTER); name.setMaxLines(2); card.addView(name);
        card.setOnFocusChangeListener((v,focus)->{v.setBackground(shape(focus?Color.rgb(38,51,69):PANEL,22)); if(focus)v.setElevation(8f);else v.setElevation(0f);});
        card.setOnClickListener(v->{Intent launch=pmLaunch(app.pkg); if(launch!=null)startActivity(launch);}); grid.addView(card);
    } if(grid.getChildCount()>0) grid.getChildAt(0).requestFocus(); }
    private Intent pmLaunch(String pkg){ return getPackageManager().getLaunchIntentForPackage(pkg); }
    @Override protected void onResume(){super.onResume(); if(grid!=null)loadApps();}
    @Override public boolean onKeyDown(int keyCode, KeyEvent event){ if(keyCode==KeyEvent.KEYCODE_MENU){loadApps();return true;} return super.onKeyDown(keyCode,event); }
}
